---
type: "contact"
description: "Клиент проекта Delta"
tags: ["work","client"]
status: "active"
confidence: "EXTRACTED"
created: "2026-09-07"
source: "daily/2026-09-07.md"
updated: "2026-09-08"
---

# Acme

Клиент проекта Delta. Получает коммерческое предложение.

## Log

- 2026-09-08: Клиент проекта Delta. Получает коммерческое предложение. Требует SLA 99,5%. Фиксация цены на 30 дней — под вопросом, требует проверки маржи.
