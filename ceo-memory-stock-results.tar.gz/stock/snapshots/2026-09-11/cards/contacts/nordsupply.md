---
type: "contact"
description: "Поставщик API для проекта Delta"
tags: ["work","partner","api-provider"]
status: "active"
confidence: "EXTRACTED"
created: "2026-09-07"
source: "daily/2026-09-07.md"
updated: "2026-09-11"
---

# NordSupply

Поставщик API для проекта Delta.

## Log

- 2026-09-08: Поставщик API для проекта Delta. Задержка передачи API. Рабочие credentials будут переданы 11 сентября в 10:00.
- 2026-09-11: Поставщик API для проекта Delta. Credentials отправлены 11 сентября в 09:18. Доступ проверен, работает. Блокера нет.
