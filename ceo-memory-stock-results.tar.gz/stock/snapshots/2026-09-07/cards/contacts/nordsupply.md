---
type: "contact"
description: "Поставщик API для проекта Delta"
tags: ["work","partner","api-provider"]
status: "active"
confidence: "EXTRACTED"
created: "2026-09-07"
source: "daily/2026-09-07.md"
---

# NordSupply

Поставщик API для проекта Delta.
